package practice;

public class SleepWaitDemo{

	private static Object LOCK= new Object();
	
	public static void main(String[] args) {
		
	
			try {
				
				Thread.sleep(2000);  
				System.out.println(Thread.currentThread().getName()+ " is  woke up after "
						+ "2 seconds of sleep");
				
				synchronized (LOCK) {
					LOCK.wait(4000);
					System.out.println("Object is woke up after wait of 4 seconds");
				}
				
				
			}
			 catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
				System.out.println("Error Occured: "+e);
			}
		
		
	}
}
