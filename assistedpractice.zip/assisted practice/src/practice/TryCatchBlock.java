package practice;

public class TryCatchBlock {

	
	public static void main(String[] args) {

		    String a="A";
		    int number;

			try {

				//Risky code //code which is going to  throw an error

				number=Integer.parseInt(a);
				System.out.println("Number is "+number);
			}
			catch (Exception e) {
				// TODO: handle exception

				System.out.println("Exception Occured: "+e);
			}
			
			//arithmetic exception
			int x=0;
			int y=0;


			try {
				int c=x/y;
				System.out.println("Result is: "+c);

			} catch (ArithmeticException e) {
				// TODO: handle exception
				System.out.println("Error: "+e);
			}
			
			
    			
		    //multiple catch block
			try {

				int result= 10/8;
				System.out.println("result is: "+result);
 
				int arr[]= {1,2,3,4,5};
				System.out.println("Value  at index 3: "+arr[3]);

				String name=null;
				name.equals("user");

				Thread.sleep(100);
			} 
			catch(ArithmeticException e) {
				System.out.println("Arithmatic Execption: "+e.getMessage());
			}

			catch(ArrayIndexOutOfBoundsException e) {
				System.out.println("Array Index Issue: "+e.getMessage());
			}
			catch(NullPointerException e) {
				System.out.println("Object is Null: "+e.getMessage());
			}
			catch(InterruptedException e) {
				System.out.println("Error Working with Thread: "+e.getMessage());
			}
			//should keep  it last
			catch (Exception e) {
				// TODO: handle exception
				System.out.println("Error occured: "+e.getMessage());
			}
			
			//another way
			try {
				test();
			}
			catch (Exception e) {
				// TODO: handle exception
				System.out.println("Error occured: "+e.getMessage());
			}
			

    }
	static void check(int age) throws Exception
	{
		if(age<18)
			System.out.println("Not Valid Age For  Voting");
		else
			System.out.println("Valid Age for Voting");
	}

	static void test() throws Exception
	{
		check(14);
	}

}
