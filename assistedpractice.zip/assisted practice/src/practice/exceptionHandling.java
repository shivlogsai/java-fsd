package practice;

public class exceptionHandling {
	public static void main(String args[]) {
	int x=0;
	int y=0;


	try {
		int c=x/y;
		System.out.println("Result is: "+c);

	} catch (ArithmeticException e) {
		// TODO: handle exception
		System.out.println("Error: "+e);
	}
}
}