package assistedPractice3;

public class Sender {
	public void send(String msg) {
		System.out.println("Sending msg... "+msg);
		
		try {
			Thread.sleep(1000);
		}
		catch(InterruptedException e) {
			e.getStackTrace();
		}
		
		System.out.println("Message sent successfully");
	}
    
}
