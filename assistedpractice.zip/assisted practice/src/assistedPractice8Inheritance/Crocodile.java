package assistedPractice8Inheritance;

public class Crocodile extends Animal {
	   
	void swim() {
		System.out.println("can swim...");
	}
   
}
