package assistedPractice8Inheritance;

public class BabyDog extends Dog{
	   void weep() {
		   System.out.println("Weeping...");
	   }
	}
