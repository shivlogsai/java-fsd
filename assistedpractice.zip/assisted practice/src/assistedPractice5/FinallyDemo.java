package assistedPractice5;

public class FinallyDemo {
    
    public static void main(String args[]) {
    	
    	 
         int a=10,b=0;
         int sum=0;
         
         int arr[]=new int[5];
         
         try {
        	 sum=a/b;
        	 
        	 arr[9]=10;
         }
         catch(Exception e) {
        	 e.printStackTrace();
         }
         finally {
        	 System.out.println("Whether the exception is handled or not, it will print");
        	 System.out.println(sum);
        	 System.out.println(arr.length);
         }
   
    }
}