import java.util.* ;
public class Pqueue_Demo {
	public static void main(String[] args) {
		
		PriorityQueue<Integer> pQueue= new PriorityQueue<Integer>(); 
		
		pQueue.add(45);
		pQueue.add(57);
		pQueue.add(78);
		pQueue.add(23);
		System.out.println(pQueue);
		System.out.println("Top Element: " + pQueue.peek());
		System.out.println("Printing the top element and removing: "+pQueue.poll());
		System.out.println(pQueue);
		System.out.println("Top Element: " + pQueue.peek());
		pQueue.remove(57);
		System.out.println("After Remove : "+pQueue);
	}
}
