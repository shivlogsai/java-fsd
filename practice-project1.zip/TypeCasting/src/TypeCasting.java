import java.util.* ;
public class TypeCasting {
	public static void main(String[] args) {
		System.out.println("Implicit TypeCasting Or Widening");
		char a= 'L';
		int b=a;
		System.out.println("a value = "+ a);
		System.out.println("b value = "+ b);
		System.out.println("\n");
		System.out.println("Explicit Typecasting Or Narrowing");
		int c =100;
		char d = (char) c;
		System.out.println("c value = "+ c);
		System.out.println("d value = "+ d);
		
	}
}
