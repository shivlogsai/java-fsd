import java.util.* ;
public class Tree_demo {
	public static void main(String[] args) {
		Set<String> set = new TreeSet<String>(); 
		
		set.add("Mango");
		set.add("Watermelon");
		set.add("Grapes");
		set.add("Apple");
		System.out.println(set);
		
		System.out.println("Size: "+set.size());
		
		System.out.println("Contains: "+ set.contains("Apple"));
	}
}
