package practicelessonfour;

import java.util.Scanner;

public class ArrayRotation {
    public void rotate(int num[],int k) {
    	
    	if(k>num.length) {
    		k=k%num.length; //10 divide by 7 will give remainder as 3
    		//no of elements rotated=remainder=2
    		//no of elements got skipped=7-3=4(not be rotated)
    		
    		int result[]=new int[num.length];//create new array with the size of the array
    		
    		
    		for(int i=0;i<k;i++) {
    			result[i]=num[num.length-k+i];  //7-3=4 this 
    			//will skip the four elements(3rd index) rest will be rotated 
    		}
    		
    		int j=0;
    		for(int i=k;i<num.length;i++) {
    			result[i]=num[j];
    			j++;
    		}
    		
    		System.arraycopy(result, 0, num, 0, num.length);
    	}
    }
    
    public static void main(String[] args) {
    	ArrayRotation r=new ArrayRotation();
    	Scanner sc=new Scanner(System.in);
    	int arr[]= {1,2,3,4,5,6,7};
    	System.out.println("No of times you want to rotate: ");
    	int times=sc.nextInt();
    	times+=arr.length;
    	r.rotate(arr,times); //passing a array and number of times to rotate
    	
    	for(int i=0;i<arr.length;i++) {
    		System.out.print(arr[i]+" ");
    	}
    }
}

