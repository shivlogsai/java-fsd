package com;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginApp
 */
public class LoginApp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginApp() {
        super();
       
    }
    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		String username = request.getParameter("uname");  
		String password = request.getParameter("pwd");
		if(username.equals("Logeshwaran") && password.equals("Logesh@123")) {
			pw.println("Successfully logged in with get method");
			
		}else {
			pw.println("login failed,try once again with get method");
		}
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		String username = request.getParameter("uname");   
		String password = request.getParameter("pwd");
		if(username.equals("Logeshwaran") && password.equals("Logesh@123")) {
			pw.println("Successfully logged in with post method");
			
		}else {
			pw.println("login failed,try once again with post method");
		}
		
	}

}
